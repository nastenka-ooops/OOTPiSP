module com.example.lapa12 {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.lapa12 to javafx.fxml;
    exports com.example.lapa12;
}