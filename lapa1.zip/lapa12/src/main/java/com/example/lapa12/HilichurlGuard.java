package com.example.lapa12;

import javafx.scene.image.Image;

public class HilichurlGuard extends HilichurlFighter{
    private Element shield;

    public HilichurlGuard(int level, Element club, Element shield) {
        super(level, club);
        this.shield = shield;
        this.setImage(new Image("https://i.pinimg.com/564x/c9/60/19/c960197d6ec5561bb1af794980d224f7.jpg", 130, 140, true, true));
        this.setName("Guard");
    }

    public Element getShield() {
        return shield;
    }

    public void setShield(Element shield) {
        this.shield = shield;
    }

    @Override
    String printInfo(){
        return super.printInfo() + " and " + this.getShield() + " shield";
    }
}
