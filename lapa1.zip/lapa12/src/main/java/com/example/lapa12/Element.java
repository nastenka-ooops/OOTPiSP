package com.example.lapa12;

public enum Element {
    GEO, CRIO, ELECTRO, HYDRO, DENDRO, FIRE, ANEMO
}
