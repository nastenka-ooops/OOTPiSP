package com.example.lapa12;

import javafx.scene.image.Image;

public class Hilichurl {
    private int level;
    private int XP;
    final int maxXP;
    private String name;
    private Image image;

    public Hilichurl(int level) {
        this.level = level;
        if (level <= 0) {
            this.maxXP = 100;
        } else if (level > 0 && level < 30) {
            this.maxXP = 1000;
        } else if (level >= 30 && level < 70) {
            this.maxXP = 5000;
        } else if (level >= 70 && level < 100) {
            this.maxXP = 10000;
        } else {
            this.maxXP = 15000;
        }
        this.XP= this.maxXP;
        this.name = "Hilichurl";
        this.image = new Image("https://i.pinimg.com/564x/31/63/13/31631396befea4c9e031a9639b42d8fe.jpg", 150, 140, true, true);
    }

    String printInfo() {
        return "This is " + this.getName() + " of " + this.getLevel() + " level with " + this.getXP() + " XP";
    }
    void recovery (){
        this.XP=this.maxXP;
    }

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public int getXP() {
        return XP;
    }

    public Image getImage() {
        return image;
    }

    public void setImage(Image image) {
        this.image = image;
    }

    public void setXP(int XP) {
        this.XP = XP;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
