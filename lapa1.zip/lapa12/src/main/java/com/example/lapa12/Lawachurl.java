package com.example.lapa12;

import javafx.scene.image.Image;

public class Lawachurl extends Mitachurl{
    private Element shell;

    public Lawachurl(int level, Element axe, Element shield, Element shell) {
        super(level, axe, shield);
        this.shell = shell;
        this.setImage(new Image("https://i.pinimg.com/564x/75/a2/77/75a27757ef920f0f6a8c8f0addf216d7.jpg", 130, 140, true, true));
        this.setName("Grenadier");
    }
    @Override
    String printInfo(){
        return super.printInfo() + " and " + this.getShell() + " shell";
    }

    public Element getShell() {
        return shell;
    }

    public void setShell(Element shell) {
        this.shell = shell;
    }
}
