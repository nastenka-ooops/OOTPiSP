package com.example.lapa12;

import javafx.scene.image.Image;

public class HilichurlGrenadier extends Hilichurl {
    private Element slime;

    public HilichurlGrenadier(int level, Element slime) {
        super(level);
        this.slime = slime;
        this.setImage(new Image("https://i.pinimg.com/564x/b2/5e/fe/b25efe338b7edb060527d08a3b6376ac.jpg", 150, 140, true, true));
        this.setName("Grenadier");
    }

    public Element getSlime() {
        return slime;
    }

    public void setSlime(Element slime) {
        this.slime = slime;
    }

    @Override
    String printInfo(){
        return super.printInfo()+ " with " + this.getSlime()+ " slime";
    }
}
