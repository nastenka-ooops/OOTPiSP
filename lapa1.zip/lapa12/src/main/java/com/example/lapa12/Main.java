package com.example.lapa12;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.RowConstraints;
import javafx.stage.Stage;

public class Main extends Application {
    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage stage) throws Exception {
        GridPane root = new GridPane();
        for (int i = 0; i < 5; i++) {
            root.getColumnConstraints().add(new ColumnConstraints(140));
        }
        for (int i = 0; i < 3; i++) {
            root.getRowConstraints().add(new RowConstraints(150));
            root.getRowConstraints().add(new RowConstraints(80));
        }
        Logic logic = new Logic();
        Hilichurl[] hilichurls = new Hilichurl[7];
        hilichurls = logic.createHilichurls(hilichurls);
        logic.showHilichurls(hilichurls, root);
        hilichurls = logic.recoverHilichurls(hilichurls);

        Scene scene =new Scene(root, 700,700);
        stage.setTitle("lapa1");
        stage.setScene(scene);
        stage.show();
    }
}