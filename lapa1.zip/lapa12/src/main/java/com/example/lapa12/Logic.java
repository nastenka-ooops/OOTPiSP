package com.example.lapa12;

import javafx.scene.control.Label;
import javafx.scene.control.MenuItem;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;

import java.io.FileNotFoundException;

public class Logic {
    public Hilichurl[] createHilichurls(Hilichurl[] hilichurls) throws FileNotFoundException {
        hilichurls[0] = new Hilichurl(20);
        hilichurls[1] = new Mitachurl(44, Element.ANEMO, Element.DENDRO);
        hilichurls[2] = new HilichurlGrenadier(67, Element.ANEMO);
        hilichurls[3] = new HilichurlShooter(55, Element.ELECTRO);
        hilichurls[4] = new HilichurlFighter(30, Element.FIRE);
        hilichurls[5] = new Lawachurl(89, Element.HYDRO, Element.GEO, Element.FIRE);
        hilichurls[6] = new HilichurlGuard(78, Element.CRIO, Element.GEO);

        /*Mitachurl mitachurl = new Mitachurl(34, Element.HYDRO, Element.GEO);
        Lawachurl lawachurl = new Lawachurl(34, Element.FIRE, Element.GEO, Element.CRIO);
        lawachurl=mitachurl;
        mitachurl=lawachurl;*/
        return hilichurls;

    }

    public Hilichurl[] recoverHilichurls(Hilichurl[] hilichurls){
        for (Hilichurl hilichurl :
                hilichurls) {
            hilichurl.recovery();
        }
        return hilichurls;
    }
    public void showHilichurls(Hilichurl[] hilichurls, GridPane gridPane){

        Label label = new Label();
        label.setWrapText(true);
        gridPane.add(new ImageView(hilichurls[0].getImage()), 2,0);
        label.setText(hilichurls[0].printInfo());
        gridPane.add(label, 2,1);
        for (int i = 1; i < 5 ; i++) {
            Label label1 = new Label();
            label1.setWrapText(true);
            label1.setText(hilichurls[i].printInfo());
            if (i<=2){
                gridPane.add(new ImageView(hilichurls[i].getImage()), i-1,2);
                gridPane.add(label1, i-1,3);
            }
            else {
                gridPane.add(new ImageView(hilichurls[i].getImage()), i, 2);
                gridPane.add(label1, i,3);
            }
        }
        Label label2 = new Label();
        label2.setWrapText(true);
        gridPane.add(new ImageView(hilichurls[5].getImage()), 0,4);
        label2.setText(hilichurls[5].printInfo());
        gridPane.add(label2, 0,5);

        Label label3 = new Label();
        label3.setWrapText(true);
        gridPane.add(new ImageView(hilichurls[6].getImage()), 4,4);
        label3.setText(hilichurls[6].printInfo());
        gridPane.add(label3, 4,5);
    }
}
