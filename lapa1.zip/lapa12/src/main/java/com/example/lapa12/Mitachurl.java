package com.example.lapa12;

import javafx.scene.image.Image;

public class Mitachurl extends Hilichurl{
    private Element axe;
    private Element shield;

    public Mitachurl(int level, Element axe, Element shield) {
        super(level);
        this.axe = axe;
        this.shield = shield;
        this.setImage(new Image("https://i.pinimg.com/564x/69/33/13/6933133dc9a3480007564d366869b54c.jpg", 130, 140, true, true));
        this.setName("Mitachurl");
    }
    @Override
    String printInfo(){
        return super.printInfo() + " with " + this.getAxe() + " axe and " + this.getShield()+ " shield";
    }

    public Element getAxe() {
        return axe;
    }

    public void setAxe(Element axe) {
        this.axe = axe;
    }

    public Element getShield() {
        return shield;
    }

    public void setShield(Element shield) {
        this.shield = shield;
    }
}
