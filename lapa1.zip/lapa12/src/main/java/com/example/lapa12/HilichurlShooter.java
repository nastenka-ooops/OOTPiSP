package com.example.lapa12;

import javafx.scene.image.Image;

public class HilichurlShooter extends Hilichurl{
    private Element crossbow;

    public HilichurlShooter(int level, Element crossbow) {
        super(level);
        this.crossbow = crossbow;
        this.setImage(new Image("https://i.pinimg.com/564x/25/99/cb/2599cbc60666fdec02f277c85d6c95b3.jpg", 150, 140, true, true));
        this.setName("Shooter");
    }

    public Element getCrossbow() {
        return crossbow;
    }

    public void setCrossbow(Element crossbow) {
        this.crossbow = crossbow;
    }

    @Override
    String printInfo(){
        return super.printInfo() + " with " + this.getCrossbow() + " crossbow";
    }
}
