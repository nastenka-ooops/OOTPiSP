package com.example.lapa12;

import javafx.scene.image.Image;

public class HilichurlFighter extends Hilichurl{
    private Element club;

    public HilichurlFighter(int level, Element club) {
        super(level);
        this.club = club;
        this.setName("Fighter");
        this.setImage(new Image("https://i.pinimg.com/564x/46/01/1f/46011f57136f6e991cb1f1b996448f7e.jpg", 130, 140, true, true));
    }

    public Element getClub() {
        return club;
    }

    @Override
    String printInfo(){
        return super.printInfo() +"with " + this.getClub() + " club ";
    }
}
